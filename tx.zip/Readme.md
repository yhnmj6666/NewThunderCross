# NewThunderCross

__Provide another way to call Thunder in Firefox57+.__
__Inspired by xThunder.__

Current Version: `0.2.3`

Please make sure the tiny Native Client is configured properly

You can Download it here:
* [x64](https://github.com/yhnmj6666/NewThunderCross/releases/download/v0.2.3/ThunderCross_x64.exe)
* [x86](https://github.com/yhnmj6666/NewThunderCross/releases/download/v0.2.3/ThunderCross_x86.exe)